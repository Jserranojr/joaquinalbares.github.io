/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package competicion;

import static competicion.ConsultasMethods.MostrarEquiposPorLiga;
import static competicion.ConsultasMethods.MostrarPartidosJugados;
import static competicion.ConsultasMethods.listarJugadores;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Jp
 */
public class COMPETICION {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {

        Scanner teclado = new Scanner(System.in);
        int opcion = 0;

        //crear 1a instancia de jugadores
        Jugadores jugadores = new Jugadores();
        EquipoService equipos = new EquipoService();
        //Equipo t1 = new Equipo();

        while (opcion != 5) {

            System.out.println("Bienvindo al Menu, elija su opcion\n"
                    + "1- crear nuevo jugador\n"
                    + "2- Añadir un Equipo\n"
                    + "3- Listar jugadores"
                    + "4- Mostrar Partidos\n"
                    + "5- Salir");

            opcion = teclado.nextInt();

            switch (opcion) {
                case 1:
                    if (equipos.comprobarHayEquipos() == true) {

                        System.out.println(" Introduce los datos del jugador en el orden, [Nombre, Nacionalidad,Edad,Posicion,Equipos]separados por comas");
                        String Datos = teclado.next();

                        String DatosSplit[] = Datos.split(",");

                        // split metodo de la clase array
                        //Coge un String y la cadena que le paso le va dividiendo / separando los valores que le paso por el split, cada vez que encuentra una coma el valor de antes lo mete en un array
                        //lo he hecho para cuando vaya a meter datos de los usuarios no tener que hacer 500 souts.
                        System.out.println("Introduce las estadisticas");

                        //objetos estadisticas
                        //esto lo que hace que en lugar de crear una variable de la clase jugadores y añadirla al metodo pasarla por parametros, lo que hace es pasar directamente
                        // una instancia sin pasarle una referencia, directmente le pasa una instancia y eso lo que hace es no tener que usar una variable solo para el metodo.
                        //realmente no es necesario instanciar los objetos al pasarlos por parametros porque al salir del switch se borrarían las referencias a las variables, pero es una buena
                        //prácitca no dejar referencia sueltas por el codigo o no dejar cosas sueltas sin usar.
                        // en lugar de crear un j1 que es una referencia de una instancia de un jugar, lo que hace es instanciar la calse directamente y pasarsela al metodo
                        // y de esa forma no vas a dejar en memoria referencias que no este usando.
                        String DatosEstadisticas[] = teclado.next().split(",");

                        jugadores.guardarJugadorenBd(new Jugador(DatosSplit[0], DatosSplit[1], Integer.valueOf(DatosSplit[2]), DatosSplit[3], DatosSplit[4]),
                                new Stats(DatosEstadisticas[0], Integer.valueOf(DatosEstadisticas[1]), Integer.valueOf(DatosEstadisticas[2]),
                                        Integer.valueOf(DatosEstadisticas[3]),
                                        Integer.valueOf(DatosEstadisticas[4]), Integer.valueOf(DatosEstadisticas[5]), Integer.valueOf(DatosEstadisticas[6])));

                        System.out.println("Jugador registrado con exito");

                    } else {
                        //aqui saltaria error si no hay un equipo creado primero
                        System.out.println("Para crear un jugdor debes crear primero un equipo");

                    }

                case 2:
                    System.out.println("¿Deseas crear un equipo nuevo?");
                    String compatible = teclado.nextLine();

                    System.out.println("Intrduzca los datos del equipo en el siguiente orden: Nombre, Ciudad, Pais ");
                    String opcion2;
                    // Instanciamiento de LinkedList
                    LinkedList<Partido> partidos = new LinkedList<Partido>();
                    // esto es para crear en memoria una refrencia de 6 posiciones de los string de partidos
                    String Opcion2[] = new String[6];
                    do {
                        System.out.println("Introduzca los datos de los partidos separado por , o introduzca 0 para salir");
                        opcion2 = teclado.next();
                        Opcion2 = opcion2.split(",");

                        partidos.add(new Partido(Integer.valueOf(Opcion2[0]), Opcion2[1], Opcion2[2], Integer.valueOf(Opcion2[3]), Integer.valueOf(Opcion2[4]), Integer.valueOf(Opcion2[5])));
                        // ! contrario de 

                    } while (!opcion2.equals("0"));

                    // almacenar datos del escaner
                    String Datos = teclado.next();

                    // aqui le estoy diciendo que el array DateSplit es = al scanner 
                    String DateSplit[] = Datos.split(",");

                    equipos.añadirNuevoEquipo(new Equipo(DateSplit[0], DateSplit[1], DateSplit[2], DateSplit[3], partidos));
                    
                    System.out.println(" Equipo añadido con exito¡");
                    break;

                case 3:
                listarJugadores();
                    break;

                case 4:
                     MostrarPartidosJugados();
                    break;

                case 5:
                    
                    break;

                default:
                    throw new AssertionError();
            }

        }

        //MostrarEquiposPorLiga();
    }

}
