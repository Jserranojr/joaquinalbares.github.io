/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package competicion;

import static competicion.Jugadores.conexion;
import java.sql.DriverManager;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

/**
 * Esta clase proporciona métodos para realizar consultas sobre equipos y jugadores en una base de datos.
 * Se incluyen métodos para mostrar la liga de un equipo, listar jugadores de un equipo y mostrar partidos jugados por un equipo.
 * 
 * @author Jp
 */
public class ConsultasMethods {
/**
     * Muestra la liga a la que pertenece un equipo especificado por el usuario.
     * 
     */
    
    
    public static void MostrarEquiposPorLiga() {

        Connection conexion = null;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduzca el nombre del equipo para ver su liga");

        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplee", "root", "Almagro88");
            System.out.println(" ");

            String nombreEquipo = teclado.nextLine();

            Statement stmt = conexion.createStatement();
            ResultSet res = stmt.executeQuery("SELECT Liga FROM equipos WHERE nombre='" + nombreEquipo + "'");

            if (res.next()) {
                String liga = res.getString(1);
                System.out.println("La liga de " + nombreEquipo + " es: " + liga);
            } else {
                System.out.println("El equipo introducido no existe");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error , el equipo introducido no existe");
        }

    }
 /**
     * Lista los jugadores de un equipo especificado por el usuario.
     * 
     */
    //Mostrar los jugadores de un equipo seleccionado previamente por teclado
    public static void listarJugadores() {

        Connection conexion = null;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduzca el nombre del equipo para mostrar sus jugadores");

        try {

            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplee", "root", "Almagro88");
            System.out.println(" ");

            String nombreEquipo = teclado.nextLine();

            Statement stmt = conexion.createStatement();
            ResultSet res = stmt.executeQuery("SELECT Nombre FROM jugadores WHERE Nombre_equipo='" + nombreEquipo + "'");

            if (res.next()) {
                System.out.println("Jugadores del equipo " + nombreEquipo + ":");
                do {
                    String jugador = res.getString(1);
                    System.out.println(jugador);
                } while (res.next());
            } else {
                System.out.println("El equipo introducido no existe o no tiene jugadores registrados");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

    }
    
/**
     * Muestra los partidos jugados por un equipo especificado por el usuario, ya sea como local o visitante.
     * 
     */
    public static void MostrarPartidosJugados() {

        Connection conexion = null;

        Scanner teclado = new Scanner(System.in);

        System.out.println("Introduzca el partido que desea consultar");
        String equipo = teclado.nextLine();
        System.out.println("seleccione si quiere ver al equipo como local o visitante");
        String condicion = teclado.nextLine();

        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplee", "root", "Almagro88");
            System.out.println(" ");
            Statement stmt = conexion.createStatement();
            if (condicion.equals("local")) {
                ResultSet reslocal = stmt.executeQuery("select * from partidos where equipo_local ='" + equipo + "'; ");

                System.out.println(" Partidos del " + equipo + " Como Local");
                while (reslocal.next()) {

                    System.out.println("\n Local");
                    System.out.println(reslocal.getString(2));
                    System.out.println("\n Visitante");
                    System.out.println(reslocal.getString(3));
                    System.out.println(" ");
                    System.out.println(reslocal.getString(4));
                    System.out.println("  ");
                    System.out.println(reslocal.getString(5));
                    System.out.println("    ");
                    System.out.println(reslocal.getString(6));
                    System.out.println(" ");
                    System.out.println(" ");

                }
            } else { // se muestran los partidos como visitante

                ResultSet resvisitante = stmt.executeQuery("select * from partidos    where equipo_visitante ='" + equipo + "'; ");
                System.out.println(" Partidos del " + equipo + " Como Visitante");

                while (resvisitante.next()) {

                    System.out.println("\n Local");
                    System.out.println(resvisitante.getString(2));
                    System.out.println("\n Visitante");
                    System.out.println(resvisitante.getString(3));
                    System.out.println(" ");
                    System.out.println(resvisitante.getString(4));
                    System.out.println("  ");
                    System.out.println(resvisitante.getString(5));  
                    System.out.println("    ");
                    System.out.println(resvisitante.getString(6));
                    System.out.println(" ");
                    System.out.println(" ");

                }

            }

        } catch (Exception e) {
        }

    }

    // Este método es solo un relleno ya que no proporcionaste la implementación
    private static Connection conexion() {
        // Aquí va tu lógica de conexión a la base de datos
        System.out.println("Conexion realizada cone exito"); // Agregado
        return null;
    }

}
//parentesis if
    
   
    
    
    


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   /* private static Connection conexion() {
        Connection conn = null;
        try {
            // Establecer la conexión
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tu_basededatos", "usuario", "contraseña");
            System.out.println("Conexion realizada con exito");
        } catch (SQLException e) {
            // Manejar errores de conexión
            e.printStackTrace();
        }
        return conn;
    }
     }*/
