/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package competicion;

import java.util.LinkedList;

/*/**
 * La clase Equipo representa un equipo de fútbol con atributos
 * como nombre, ciudad, país y liga. Además, mantiene una lista de
 * partidos jugados por el equipo.
 */
 
public class Equipo {
  
  private String Nombre;
  private String Ciudad;
  private String Pais;
  private String Liga;
  /**
   * Lista de partidos jugados por el equipo.
   */
  LinkedList<Partido>partidos;
  
   /**
   * Constructor para crear una nueva instancia de la clase Equipo.
   * 
   * @param Nombre el nombre del equipo
   * @param Ciudad la ciudad del equipo
   * @param Pais el país del equipo
   * @param Liga la liga en la que juega el equipo
   * @param partidos la lista de partidos jugados por el equipo
   */
  
    public Equipo(String Nombre, String Ciudad, String Pais,String Liga,LinkedList<Partido>partidos) {
        this.Nombre = Nombre;
        this.Ciudad = Ciudad;
        this.Pais = Pais;
        this.Liga=Liga;
        this.partidos=partidos;
    }
 /**
   * Obtiene el nombre del equipo.
   * 
   * @return el nombre del equipo
   */
    public String getNombre() {
        return Nombre;
    }
/**
   * Establece el nombre del equipo.
   * 
   * @param Nombre el nuevo nombre del equipo
   */
    /**
     * 
   * Obtiene la liga en la que juega el equipo.
   * 
   * @return la liga del equipo
   */
    public String getLiga() {
        return Liga;
    }
/**
   * Establece la liga en la que juega el equipo.
   * 
   * @param Liga la nueva liga del equipo
   */
    public void setLiga(String Liga) {
        this.Liga = Liga;
    }
/**
   * Obtiene la lista de partidos jugados por el equipo.
   * 
   * @return la lista de partidos
   */
    public LinkedList<Partido> getPartidos() {
        return partidos;
    }
/**
   * Establece la lista de partidos jugados por el equipo.
   * 
   * @param partidos la nueva lista de partidos
   */
    public void setPartidos(LinkedList<Partido> partidos) {
        this.partidos = partidos;
    }
/**
   * (Método duplicado) Obtiene la lista de partidos jugados por el equipo.
   * 
   * @return la lista de partidos
   */
    public LinkedList<Partido> getPartido() {
        return partidos;
    }
/**
   * (Método duplicado) Establece la lista de partidos jugados por el equipo.
   * 
   * @param partidos la nueva lista de partidos
   */
    public void setPartido(LinkedList<Partido> partidos) {
        this.partidos = partidos;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
/**
   * Obtiene la ciudad del equipo.
   * 
   * @return la ciudad del equipo
   */
    public String getCiudad() {
        return Ciudad;
    }
/**
   * Establece la ciudad del equipo.
   * 
   * @param Ciudad la nueva ciudad del equipo
   */
    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }
/**
   * Obtiene el país del equipo.
   * 
   * @return el país del equipo
   */
    public String getPais() {
        return Pais;
    }
/**
   * Establece el país del equipo.
   * 
   * @param Pais el nuevo país del equipo
   */
    public void setPais(String Pais) {
        this.Pais = Pais;
    }
  
    
    
    
    
}
