/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package competicion;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import static competicion.Jugadores.conexion;
import static competicion.Jugadores.conexion;
import java.util.LinkedList;

/**
 *
 * @author Jp
 */
public class EquipoService {
    
    
    public void añadirNuevoEquipo(Equipo equipos){
        
        
    Connection conexion = conexion();
    
        try {
            
            String sql = ("Insert into equipos (Nombre, Ciudad, País, Liga) values (?,?,?,?)");
            
            PreparedStatement stmt = conexion.prepareStatement(sql);
            
                stmt.setString(1,equipos.getNombre());
                stmt.setString(2, equipos.getCiudad());
                stmt.setString(3, equipos.getPais());
                stmt.setString(4, equipos.getLiga());
                
            stmt.executeUpdate();
        
            
        } catch (Exception e) {
            System.out.println(" Error al insertar el equipo en bd");
        }
    
    
    
    }
    
    
    public void agregarPartidos(Equipo equipos ,LinkedList<Partido>partidos){
    
         Connection conexion = conexion();
         String sql =("Insert into partidos  (codigo, equipo_local,equipo_visitante,goles_local,goles_visitante,temporada) values (?,?,?,?,?,?)");
        
        
         try {
            
          
              for (int i = 0; i < partidos.size(); i++) {
                  
            PreparedStatement stmt = conexion.prepareStatement(sql);
                  
                  stmt.setInt(1, partidos.get(i).getCodigo());
                  stmt.setString(1, partidos.get(i).getEquipoLocal());
                  stmt.setString(1, partidos.get(i).getEquipoVisitante());
                  stmt.setInt(1, partidos.get(i).getGolesLocales());
                  stmt.setInt(1, partidos.get(i).getGolesVisitante());
                  stmt.setInt(1, partidos.get(i).getTemporada());
               
                  stmt.executeUpdate();
                  
            
            }
             
             
             
             
             
             
        } catch (Exception e) {
             System.out.println(" error al agregar partidos a un equipo "+equipos);
        }
        
    
    }
    
    
    
    
    
    public boolean comprobarHayEquipos(){
    
    Connection conexion = conexion();
    
        try {
            PreparedStatement statement= conexion.prepareStatement("SELECT Nombre FROM equipos");
            ResultSet rs = statement.executeQuery();
            
            if (rs.getString(1).length()>0) {
            return true;
            }
            
            
            
            
        } catch (Exception e) {
        }
    
    
    
     return false;
    }
   
    
    
    
    
    
}
