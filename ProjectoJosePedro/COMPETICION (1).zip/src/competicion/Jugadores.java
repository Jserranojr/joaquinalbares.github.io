package competicion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Jp
 */
public class Jugadores {
    

     
    public void guardarJugadorenBd( Jugador jugador ,Stats estadisticas)  {
        
        Connection conexion = conexion();
        
    
        
        try {
            System.out.println("Introduzca los datos del jugador  que desea guardar");
           
            
            PreparedStatement statement = conexion.prepareStatement("INSERT INTO Jugadores(Nombre,Nacionalidad,Edad,Posicion,equipo) VALUES (?,?,?,?,?)");
            
            
            
        
            statement.setString(1, jugador.getNombre());
            statement.setString(2, jugador.getNacionalidad());
            statement.setInt(3, jugador.getEdad());
            statement.setString(4, jugador.getPosicion());
            statement.setString(5, jugador.getEquipo());
           
            
            
            
            
            statement.executeUpdate();
            
            statement = conexion.prepareStatement("INSERT INTO estadisticas (temporada, codigo_jugador, Nombre_jugador, Goles_por_partido, Asistencias_Por_Partida,Tarjetas_amarillas_por_partido,Tarjetas_rojas_por_partido,Entradas_por_partido) VALUES (?,?,?,?,?,?,?,?) ");
            
            PreparedStatement stt = conexion.prepareStatement("SELECT codigo from jugadores where Nombre = ?");
            stt.setString(1, jugador.getNombre());
            
           // el execute query es para obtener el codigo del jugador a raiz de una consulta de base de datos ya que el usuario no tiene porque saber el codigo del jugador
           //ya que el codigo es solo algo que pertenece a la base de datos
            ResultSet stmt = stt.executeQuery();
            statement.setString(1,estadisticas.getTemporada());
           statement.setInt(2, stmt.getInt(1));
            statement.setString(3, jugador.getNombre());
            statement.setInt(4,estadisticas.getGoles());
            statement.setInt(5, estadisticas.getAsistencias());
            statement.setInt(6,estadisticas.getTarjetasAmarillas());
            statement.setInt(7, estadisticas.getTarjetasRojas());
            statement.setInt(8, estadisticas.getEntradas());
            
            statement.executeUpdate();
           System.out.println("Jugador guardado con exito");          
                    
                    } catch (Exception e) {
                       System.out.println(" Error al introducir el jugador");
                    }
        
    }

     
    
    
    
    
    public void aztualizarDatos (Jugador jugador, Stats estadisticas ){
    
    Connection conexion = conexion();
    
        try {
            
            PreparedStatement statement = conexion.prepareStatement("UPDATE Jugadores SET Nombre = ?, Nacionalidad = ?, edad = ?, Posicion = ?, equipo =? WHERE Nombre = ?");
            
            
             
            statement.setString(1, jugador.getNombre());
            statement.setString(2, jugador.getNacionalidad());
            statement.setInt(3, jugador.getEdad());
            statement.setString(4, jugador.getPosicion());
            statement.setString(5, jugador.getEquipo());
            
            statement.executeUpdate();
            
            
            
            statement = conexion.prepareStatement("UPDATE estadisticas SET temporada=?,  jugador = ?, Goles_por_partido = ?, Asistencias_por_partido = ?,   Tarjetas_amarillas_por_partido = ?, Tarjetas_rojas_por_partido =?, Paradas_por_partido =?, Entradas_por_partido=?  WHERE temporada = ? ");
            
            statement.setString(1,estadisticas.getTemporada());
            statement.setInt(3, estadisticas.getGoles());
            statement.setInt(4,estadisticas.getAsistencias());
            statement.setInt(5, estadisticas.getTarjetasAmarillas());
            statement.setInt(6, estadisticas.getTarjetasRojas());
            statement.setInt(7, estadisticas.getEntradas());
            
            
           
            
            System.out.println("Jugador modificado con exito");
            
        } catch (Exception e) {
            System.out.println("Error no pudo ser modificado");
        }
    
    
    
    
        
        
        
        
        
        
        
        
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     
     public static Connection conexion (){
    
        Connection conexion = null;
        
        try {
            
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplee", "root", "Almagro88");
            System.out.println(" Conectado con exito");
            
            
        } catch (Exception e) {
            e.printStackTrace();
          
        }
      return conexion;
    }
     
     
     
     
    
    }
    
    
    
    

