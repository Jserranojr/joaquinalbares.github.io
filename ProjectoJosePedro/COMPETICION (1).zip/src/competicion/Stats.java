/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package competicion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import static competicion.Jugadores.conexion;

/*temporada varchar(20) NOT NULL,
    jugador int NOT NULL,
    Goles_por_partido float DEFAULT NULL,
    Asistencias_por_partido float DEFAULT NULL,
    Tarjetas_amarillas_por_partido float DEFAULT NULL,
    Tarjetas_rojas_por_partido float DEFAULT NULL,
    Paradas_por_partido float DEFAULT NULL,
    Entradas_por_partido float DEFAULT NULL,
 */
public class Stats {
    
    private String temporada;
    private int Goles;
    private int Asistencias;
    private int TarjetasAmarillas;
    private int tarjetasRojas;
    private int Paradas;
    private int Entradas;

    public Stats(String temporada, int Goles,int Asistencias, int TarjetasAmarillas, int tarjetasRojas, int Paradas, int Entradas) {
        this.temporada = temporada;
        this.Goles = Goles;
        this.Asistencias = Asistencias;
        this.TarjetasAmarillas = TarjetasAmarillas;
        this.tarjetasRojas = tarjetasRojas;
        this.Paradas = Paradas;
        this.Entradas = Entradas;
    }

    public String getTemporada() {
        return temporada;
        
    }

    public int getAsistencias() {
        return Asistencias;
    }

    

    public int getGoles() {
        return Goles;
    }

    public int getTarjetasAmarillas() {
        return TarjetasAmarillas;
    }

    public int getTarjetasRojas() {
        return tarjetasRojas;
    }

    public int getParadas() {
        return Paradas;
    }

    public int getEntradas() {
        return Entradas;
    }

    public void setTemporada(String temporada) {
        this.temporada = temporada;
    }

    

    public void setGoles(int Goles) {
        this.Goles = Goles;
    }

    public void setAsistencias(int Asistencias) {
        this.Asistencias = Asistencias;
    }

    public void setTarjetasAmarillas(int TarjetasAmarillas) {
        this.TarjetasAmarillas = TarjetasAmarillas;
    }

    public void setTarjetasRojas(int tarjetasRojas) {
        this.tarjetasRojas = tarjetasRojas;
    }

    public void setParadas(int Paradas) {
        this.Paradas = Paradas;
    }

    public void setEntradas(int Entradas) {
        this.Entradas = Entradas;
    }

   

   
    
    
   
    
    
    }

    
    
    
    
    
    

