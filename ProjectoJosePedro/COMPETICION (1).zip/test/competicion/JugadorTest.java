/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package competicion;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Jp
 */
public class JugadorTest {
    
    public JugadorTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getNombre method, of class Jugador.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNombre method, of class Jugador.
     */
    @Test
    public void testSetNombre() {
        System.out.println("setNombre");
        String Nombre = "";
        Jugador instance = null;
        instance.setNombre(Nombre);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNacionalidad method, of class Jugador.
     */
    @Test
    public void testGetNacionalidad() {
        System.out.println("getNacionalidad");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getNacionalidad();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNacionalidad method, of class Jugador.
     */
    @Test
    public void testSetNacionalidad() {
        System.out.println("setNacionalidad");
        String Nacionalidad = "";
        Jugador instance = null;
        instance.setNacionalidad(Nacionalidad);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEdad method, of class Jugador.
     */
    @Test
    public void testGetEdad() {
        System.out.println("getEdad");
        Jugador instance = null;
        int expResult = 0;
        int result = instance.getEdad();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEdad method, of class Jugador.
     */
    @Test
    public void testSetEdad() {
        System.out.println("setEdad");
        int Edad = 0;
        Jugador instance = null;
        instance.setEdad(Edad);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPosicion method, of class Jugador.
     */
    @Test
    public void testGetPosicion() {
        System.out.println("getPosicion");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getPosicion();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPosicion method, of class Jugador.
     */
    @Test
    public void testSetPosicion() {
        System.out.println("setPosicion");
        String posicion = "";
        Jugador instance = null;
        instance.setPosicion(posicion);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getEquipo method, of class Jugador.
     */
    @Test
    public void testGetEquipo() {
        System.out.println("getEquipo");
        Jugador instance = null;
        String expResult = "";
        String result = instance.getEquipo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEquipo method, of class Jugador.
     */
    @Test
    public void testSetEquipo() {
        System.out.println("setEquipo");
        String equipo = "";
        Jugador instance = null;
        instance.setEquipo(equipo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
