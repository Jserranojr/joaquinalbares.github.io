drop database simplee;
create database simplee;
use simplee;
CREATE TABLE equipos (
    Nombre varchar(30) NOT NULL,
    Ciudad varchar(30) DEFAULT NULL,
    Pais varchar(30) DEFAULT NULL,
    PRIMARY KEY (Nombre)
);

SELECT j.Nombre AS NombreJugador, j.Nombre_equipo, e.Ciudad, e.Pais
FROM jugadores j
JOIN equipos e ON j.Nombre_equipo = e.Nombre;

SELECT j.Nombre AS NombreJugador, j.Nombre_equipo
FROM jugadores j
JOIN equipos e ON j.Nombre_equipo = e.Nombre;


select * from jugadores;
select * from equipos;
INSERT INTO equipos (Nombre, Ciudad, Pais,Liga)
value('SevillaFC','Sevilla','España','LaLiga');

INSERT INTO equipos (Nombre, Ciudad, Pais,Liga)
value('ManchesterCity','Manchester','Inglaterra','PremierLeague');

INSERT INTO equipos (Nombre, Ciudad, Pais,Liga)
value('RealMadrid','Madrid','España','LaLiga');

select nombre from equipos where Liga = 'LaLiga';

select * from equipos;
select Nombre from jugadores where Nombre_equipo ='ManchesterCity';

select * from partidos;




select * from equipos where Liga = 'LaLiga';



alter table equipos add column Liga varchar (30);

select * from equipos;

CREATE TABLE jugadores (
    codigo int NOT NULL auto_increment,
    Nombre varchar(30),
    Nacionalidad varchar(30) DEFAULT NULL,
    Edad int DEFAULT NULL,
    Posicion varchar(20) DEFAULT NULL,
    Nombre_equipo varchar(30) DEFAULT NULL,
    PRIMARY KEY (codigo,Nombre),
    FOREIGN KEY (Nombre_equipo) REFERENCES equipos(Nombre)
);
SELECT Nombre, Nombre_equipo
FROM jugadores;






SELECT * 
FROM jugadores 
WHERE Nombre_equipo = 'Manchester City'
GROUP BY Nombre;




INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('KevinDeBruyne','Belgica','32','MC','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('Rodri','España','28','MCD','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('AlissonBecker','Brasil','34','POR','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('BernardoSilva','Portugal','30','MCO','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('RubenDiaz','Portugal','32','DFC','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('KyleWalker','Inglaterra','27','LD','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('John Stones','Inglaterra','31','DFC','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('ManuelAkanji','Alemania','29','LI','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('PhilFoden','Inglaterra','24','ED','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('JackGrealish','Inglaterra','28','EI','ManchesterCity');

INSERT INTO jugadores (Nombre,Nacionalidad,Edad,Posicion,Nombre_equipo)
VALUES('Erling Haaland','Noreuga','21','DC','ManchesterCity');






CREATE TABLE estadisticas (
    temporada varchar(20),
    codigo_jugador int, 
    Nombre_jugador varchar(30) ,
    Goles_por_partido int DEFAULT NULL,
    Asistencias_por_partido int DEFAULT NULL,
    Tarjetas_amarillas_por_partido int DEFAULT NULL,
    Tarjetas_rojas_por_partido int DEFAULT NULL,
    Paradas_por_partido int DEFAULT NULL,
    Entradas_por_partido int DEFAULT NULL,
	PRIMARY KEY (temporada),
    FOREIGN KEY (codigo_jugador, Nombre_jugador) REFERENCES jugadores(codigo, Nombre)
);

INSERT INTO estadisticas (temporada,codigo_jugador, Nombre_Jugador,Goles_por_partido,Asistencias_por_partido,Tarjetas_amarillas_por_partido,Tarjetas_rojas_por_partido,Paradas_por_partido,Entradas_por_partido)
VALUES('23/24',2,'KevinDeBruyne',376,1890,22,2,0,129);




select * from estadisticas;




CREATE TABLE partidos (
    codigo int NOT NULL,
    equipo_local varchar(30) DEFAULT NULL,
    equipo_visitante varchar(30) DEFAULT NULL,
    goles_local int DEFAULT NULL,
    goles_visitante int DEFAULT NULL,
    temporada varchar(20) DEFAULT NULL,
    PRIMARY KEY (codigo),
    FOREIGN KEY (equipo_local) REFERENCES equipos(Nombre),
    FOREIGN KEY (equipo_visitante) REFERENCES equipos(Nombre)
);


select * from equipos;
INSERT INTO partidos (equipo_local,equipo_visitante,goles_local,goles_visitante,temporada)
VALUES('ManchesterCity','RealMadrid',2,3,'23/24');

INSERT INTO partidos (equipo_local,equipo_visitante,goles_local,goles_visitante,temporada)
VALUES('RealMadrid','ManchesterCity',2,3,'23/24');


alter table partidos modify column goles_local











-- Inserts para la tabla partidos
-- Inserts para la tabla partidos
INSERT INTO partidos VALUES (1, 'Real Madrid', 'FC Barcelona', 2, 1, '2023-2024');
INSERT INTO partidos VALUES (2, 'Bayern Munich', 'Manchester City', 3, 2, '2023-2024');
INSERT INTO partidos VALUES (3, 'Paris Saint-Germain', 'Liverpool', 1, 1, '2023-2024');
INSERT INTO partidos VALUES (4, 'Chelsea', 'Atletico Madrid', 2, 0, '2023-2024');
INSERT INTO partidos VALUES (5, 'Manchester United', 'Juventus', 1, 2, '2023-2024');








-- Inserts para la tabla equipos
INSERT INTO equipos VALUES ('Paris Saint-Germain', 'Paris', 'Francia');
INSERT INTO equipos VALUES ('Manchester United', 'Manchester', 'Inglaterra');
INSERT INTO equipos VALUES ('Bayern Munich', 'Munich', 'Alemania');
INSERT INTO equipos VALUES ('Manchester City', 'Manchester', 'Inglaterra');
INSERT INTO equipos VALUES ('Liverpool', 'Liverpool', 'Inglaterra');
-- Inserts para los equipos Barcelona y Real Madrid
INSERT INTO equipos VALUES ('FC Barcelona', 'Barcelona', 'España');
INSERT INTO equipos VALUES ('Real Madrid', 'Madrid', 'España');





-- Inserts para la tabla jugadores
INSERT INTO jugadores VALUES ( 'Lionel Messi', 'Argentina', 34, 'Delantero', 'Paris Saint-Germain');
INSERT INTO jugadores VALUES ( 'Cristiano Ronaldo', 'Portugal', 37, 'Delantero', 'Manchester United');
INSERT INTO jugadores VALUES ( 'Neymar Jr.', 'Brasil', 30, 'Delantero', 'Paris Saint-Germain');
INSERT INTO jugadores VALUES ( 'Kevin De Bruyne', 'Bélgica', 30, 'Centrocampista', 'Manchester City');
INSERT INTO jugadores VALUES ( 'Robert Lewandowski', 'Polonia', 33, 'Delantero', 'Bayern Munich');


-- Inserts para la tabla estadisticas
INSERT INTO estadisticas VALUES ('2023-2024', 1, 1.2, 0.8, 0.1, 0.0, NULL, NULL);
INSERT INTO estadisticas VALUES ('2023-2024', 2, 1.0, 0.5, 0.2, 0.0, NULL, NULL);
INSERT INTO estadisticas VALUES ('2023-2024', 3, 1.5, 1.0, 0.3, 0.0, NULL, NULL);
INSERT INTO estadisticas VALUES ('2023-2024', 4, 0.7, 0.9, 0.4, 0.0, NULL, NULL);
INSERT INTO estadisticas VALUES ('2023-2024', 5, 1.3, 0.2, 0.0, 0.0, NULL, NULL);

-- Inserts para la tabla partidos
INSERT INTO partidos VALUES (1, 'Real Madrid', 'FC Barcelona', 2, 1, '2023-2024');
INSERT INTO partidos VALUES (2, 'Bayern Munich', 'Manchester City', 3, 2, '2023-2024');
INSERT INTO partidos VALUES (3, 'Paris Saint-Germain', 'Liverpool', 1, 1, '2023-2024');
INSERT INTO partidos VALUES (4, 'Chelsea', 'Atletico Madrid', 2, 0, '2023-2024');
INSERT INTO partidos VALUES (5, 'Manchester United', 'Juventus', 1, 2, '2023-2024');





-- Inserts para la tabla estadisticas


